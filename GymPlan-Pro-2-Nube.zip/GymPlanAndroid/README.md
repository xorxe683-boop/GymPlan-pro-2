# GymPlan Pro 2 — Android

Versión ampliada de GymPlan con galería real de fotos de ejercicios.

## Incluye
- Rutinas por día de lunes a domingo.
- Marcar ejercicios como completados.
- Editar series, repeticiones y peso.
- Historial de pesos.
- Gráfico de progreso.
- Temporizador de descanso configurable.
- Tema oscuro.
- **Galería real de ejercicios** con filtros por pecho, espalda, piernas y hombros.
- Fotos cargadas desde Wikimedia Commons mediante Internet.
- Atribución de autor y licencia visible en cada foto.
- Persistencia local mediante `localStorage`.

## Fotos y licencias
Las fotos de la galería se sirven desde Wikimedia Commons. La app muestra la fuente y la licencia asociadas a cada imagen. Algunas son de dominio público y otras tienen licencias Creative Commons que requieren atribución y/o compartir igual.

Fuentes incluidas en la galería:
- Everkinetic — Dumbbell bench press — CC BY-SA 3.0.
- U.S. Army / Emily Broda — Barbell squat — dominio público.
- Artur Andrzej — Deadlift — CC BY-SA 3.0 / GFDL.
- PTPioneer — Pull-ups — CC BY 2.0.
- U.S. Navy / William R. Goodwin — Military press — dominio público.
- U.S. Army / Kylejian Francia — Bulgarian split squat — dominio público.
- Everkinetic — Barbell rear-delt row — CC BY-SA 3.0.

## Crear la APK
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice el proyecto.
3. Selecciona **Build > Build APK(s)**.
4. La APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

Esta versión necesita permiso de Internet para mostrar las fotos remotas. Las rutinas, historial y preferencias siguen guardándose localmente.
