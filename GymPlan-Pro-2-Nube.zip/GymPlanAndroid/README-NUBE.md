# GymPlan Pro 2 — Compilación desde el teléfono

Este proyecto incluye un flujo de GitHub Actions para generar automáticamente la APK sin Android Studio.

## Pasos

1. En el teléfono crea una cuenta en GitHub si no tienes una.
2. Crea un repositorio nuevo, por ejemplo `GymPlan-Pro-2`.
3. Sube TODO el contenido de esta carpeta al repositorio. Debe quedar `app/`, `build.gradle`, `settings.gradle` y `.github/workflows/build-apk.yml` en la raíz.
4. En GitHub entra en **Actions**.
5. Selecciona **Construir APK GymPlan Pro 2**.
6. Pulsa **Run workflow** y después **Run workflow** otra vez.
7. Espera a que termine el proceso con marca verde.
8. Abre la ejecución terminada y baja hasta **Artifacts**.
9. Descarga `GymPlan-Pro-2-APK.zip`.
10. Dentro encontrarás `app-debug.apk`. Ábrela en Android para instalar GymPlan Pro 2.

No necesitas Android Studio en el teléfono.

## Nota
La compilación usa Ubuntu de GitHub, Java 17, Gradle 8.7 y el Android SDK disponible en el runner. La APK generada es una APK de depuración para instalación personal.
